import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Separator } from "./ui/separator";
import { Clock, TrendingUp, Trophy, Users, X, Plus, Minus } from "lucide-react";

interface Bet {
  id: string;
  match: string;
  selection: string;
  odds: number;
  stake: number;
}

export function Sportsbook() {
  const [betSlip, setBetSlip] = useState<Bet[]>([]);
  const [totalStake, setTotalStake] = useState(0);

  const addToBetSlip = (match: string, selection: string, odds: number) => {
    const bet: Bet = {
      id: `${match}-${selection}`,
      match,
      selection,
      odds,
      stake: 10
    };
    
    const existingBetIndex = betSlip.findIndex(b => b.id === bet.id);
    if (existingBetIndex >= 0) {
      // Remove if already exists
      setBetSlip(betSlip.filter(b => b.id !== bet.id));
    } else {
      setBetSlip([...betSlip, bet]);
    }
  };

  const updateStake = (betId: string, stake: number) => {
    setBetSlip(betSlip.map(bet => bet.id === betId ? { ...bet, stake } : bet));
  };

  const removeBet = (betId: string) => {
    setBetSlip(betSlip.filter(bet => bet.id !== betId));
  };

  const potentialPayout = betSlip.reduce((total, bet) => total + (bet.stake * bet.odds), 0);
  const totalStakeAmount = betSlip.reduce((total, bet) => total + bet.stake, 0);

  const matches = [
    {
      id: 1,
      sport: "Football",
      league: "Premier League",
      homeTeam: "Manchester City",
      awayTeam: "Arsenal",
      time: "15:00",
      date: "Today",
      odds: { home: 1.85, draw: 3.40, away: 4.20 },
      stats: { homeForm: "WWWDW", awayForm: "WDWLW" }
    },
    {
      id: 2,
      sport: "Football", 
      league: "La Liga",
      homeTeam: "Real Madrid",
      awayTeam: "Barcelona",
      time: "20:00",
      date: "Today",
      odds: { home: 2.10, draw: 3.20, away: 3.50 },
      stats: { homeForm: "WWLWW", awayForm: "WDWWL" }
    },
    {
      id: 3,
      sport: "Basketball",
      league: "NBA",
      homeTeam: "Lakers",
      awayTeam: "Warriors",
      time: "02:30",
      date: "Tomorrow",
      odds: { home: 1.95, away: 1.85 },
      stats: { homeForm: "LWWLW", awayForm: "WWWLW" }
    }
  ];

  const sports = ["All", "Football", "Basketball", "Tennis", "Baseball"];

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:ml-64">
      <div className="flex flex-col lg:flex-row min-h-screen">
        {/* Main Content */}
        <div className="flex-1 p-4">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-2">Sportsbook</h1>
            <p className="text-muted-foreground">Place your bets on live and upcoming matches</p>
          </div>

          <Tabs defaultValue="live" className="mb-6">
            <TabsList className="grid grid-cols-3 w-full max-w-md">
              <TabsTrigger value="live">Live</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="popular">Popular</TabsTrigger>
            </TabsList>

            <div className="flex flex-wrap gap-2 mt-4">
              {sports.map((sport) => (
                <Button
                  key={sport}
                  variant="outline"
                  size="sm"
                  className="rounded-full"
                >
                  {sport}
                </Button>
              ))}
            </div>

            <TabsContent value="live" className="space-y-4 mt-6">
              {matches.map((match) => (
                <Card key={match.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="bg-success/10 text-success border-success/30">
                          🔴 Live
                        </Badge>
                        <span className="text-sm text-muted-foreground">{match.league}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        {match.time}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">{match.homeTeam}</span>
                          <span className="text-xs text-muted-foreground">{match.stats.homeForm}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">{match.awayTeam}</span>
                          <span className="text-xs text-muted-foreground">{match.stats.awayForm}</span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <Button
                          variant="outline"
                          className={`h-auto py-3 px-2 flex flex-col ${
                            betSlip.some(bet => bet.id === `${match.homeTeam} vs ${match.awayTeam}-Home`) 
                              ? 'border-primary bg-primary/10' : ''
                          }`}
                          onClick={() => addToBetSlip(
                            `${match.homeTeam} vs ${match.awayTeam}`,
                            "Home",
                            match.odds.home
                          )}
                        >
                          <span className="text-xs text-muted-foreground">Home</span>
                          <span className="font-semibold">{match.odds.home}</span>
                        </Button>
                        
                        {match.odds.draw && (
                          <Button
                            variant="outline"
                            className={`h-auto py-3 px-2 flex flex-col ${
                              betSlip.some(bet => bet.id === `${match.homeTeam} vs ${match.awayTeam}-Draw`) 
                                ? 'border-primary bg-primary/10' : ''
                            }`}
                            onClick={() => addToBetSlip(
                              `${match.homeTeam} vs ${match.awayTeam}`,
                              "Draw",
                              match.odds.draw
                            )}
                          >
                            <span className="text-xs text-muted-foreground">Draw</span>
                            <span className="font-semibold">{match.odds.draw}</span>
                          </Button>
                        )}
                        
                        <Button
                          variant="outline"
                          className={`h-auto py-3 px-2 flex flex-col ${
                            betSlip.some(bet => bet.id === `${match.homeTeam} vs ${match.awayTeam}-Away`) 
                              ? 'border-primary bg-primary/10' : ''
                          }`}
                          onClick={() => addToBetSlip(
                            `${match.homeTeam} vs ${match.awayTeam}`,
                            "Away",
                            match.odds.away
                          )}
                        >
                          <span className="text-xs text-muted-foreground">Away</span>
                          <span className="font-semibold">{match.odds.away}</span>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          1.2k betting
                        </span>
                        <span className="flex items-center gap-1">
                          <TrendingUp className="w-4 h-4" />
                          $45k volume
                        </span>
                      </div>
                      <Button variant="ghost" size="sm">
                        +25 more markets
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </div>

        {/* Bet Slip Sidebar */}
        <div className="w-full lg:w-96 bg-card border-l border-border p-4">
          <div className="sticky top-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Trophy className="w-5 h-5 text-primary" />
                Bet Slip ({betSlip.length})
              </h3>
              {betSlip.length > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setBetSlip([])}
                >
                  Clear All
                </Button>
              )}
            </div>

            {betSlip.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Trophy className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Your bet slip is empty</p>
                <p className="text-sm">Select odds to add bets</p>
              </div>
            ) : (
              <div className="space-y-4">
                {betSlip.map((bet) => (
                  <Card key={bet.id} className="p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm">{bet.match}</h4>
                        <p className="text-xs text-muted-foreground">{bet.selection}</p>
                        <p className="text-sm font-semibold text-primary">@{bet.odds}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0"
                        onClick={() => removeBet(bet.id)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => updateStake(bet.id, Math.max(1, bet.stake - 5))}
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      <Input
                        type="number"
                        value={bet.stake}
                        onChange={(e) => updateStake(bet.id, parseFloat(e.target.value) || 0)}
                        className="h-8 text-center"
                        min="1"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => updateStake(bet.id, bet.stake + 5)}
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between mt-2 text-sm">
                      <span className="text-muted-foreground">Potential Win:</span>
                      <span className="font-semibold text-success">
                        ${(bet.stake * bet.odds).toFixed(2)}
                      </span>
                    </div>
                  </Card>
                ))}

                <Separator />

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Total Stake:</span>
                    <span className="font-semibold">${totalStakeAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Potential Payout:</span>
                    <span className="font-semibold text-success">${potentialPayout.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Potential Profit:</span>
                    <span className="font-semibold text-primary">
                      ${(potentialPayout - totalStakeAmount).toFixed(2)}
                    </span>
                  </div>
                </div>

                <Button className="w-full gradient-primary glow-primary" size="lg">
                  Place Bet - ${totalStakeAmount.toFixed(2)}
                </Button>

                <div className="text-xs text-muted-foreground text-center">
                  By placing this bet, you agree to our terms and conditions
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}