import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Crown, 
  Gift, 
  TrendingUp, 
  Users, 
  Star, 
  Zap, 
  Trophy, 
  Coins,
  Target,
  Calendar,
  Flame,
  Award
} from "lucide-react";

export function Rewards() {
  const vipTiers = [
    { 
      level: 0, 
      name: "Bronze", 
      color: "bg-orange-600", 
      minWager: 0, 
      rakeback: 5, 
      bonuses: 10,
      icon: "🥉"
    },
    { 
      level: 1, 
      name: "Silver", 
      color: "bg-gray-400", 
      minWager: 1000, 
      rakeback: 8, 
      bonuses: 15,
      icon: "🥈"
    },
    { 
      level: 2, 
      name: "Gold", 
      color: "bg-yellow-500", 
      minWager: 10000, 
      rakeback: 12, 
      bonuses: 20,
      icon: "🥇"
    },
    { 
      level: 3, 
      name: "Platinum", 
      color: "bg-slate-300", 
      minWager: 50000, 
      rakeback: 15, 
      bonuses: 25,
      icon: "💎"
    },
    { 
      level: 4, 
      name: "Diamond", 
      color: "bg-blue-400", 
      minWager: 250000, 
      rakeback: 20, 
      bonuses: 35,
      icon: "💎"
    },
    { 
      level: 5, 
      name: "Master", 
      color: "bg-purple-500", 
      minWager: 1000000, 
      rakeback: 25, 
      bonuses: 50,
      icon: "👑"
    }
  ];

  const currentLevel = 2; // Gold
  const currentWager = 23456;
  const nextTierWager = vipTiers[currentLevel + 1]?.minWager || 0;
  const progress = ((currentWager - vipTiers[currentLevel].minWager) / (nextTierWager - vipTiers[currentLevel].minWager)) * 100;

  const achievements = [
    { id: 1, name: "First Deposit", description: "Make your first deposit", reward: "$10 Bonus", completed: true, icon: "🎯" },
    { id: 2, name: "High Roller", description: "Wager $10,000 in a day", reward: "$100 Bonus", completed: true, icon: "💰" },
    { id: 3, name: "Lucky Streak", description: "Win 5 games in a row", reward: "50 Free Spins", completed: false, icon: "🍀" },
    { id: 4, name: "Crypto Master", description: "Use 3 different cryptocurrencies", reward: "VIP Status", completed: true, icon: "₿" },
    { id: 5, name: "Tournament Champion", description: "Win a tournament", reward: "$500 Prize", completed: false, icon: "🏆" },
    { id: 6, name: "Loyalty Reward", description: "Play for 30 consecutive days", reward: "1% Rakeback Boost", completed: false, icon: "🔥" }
  ];

  const streamers = [
    {
      id: 1,
      name: "CryptoKing88",
      followers: "152K",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face",
      status: "Live",
      game: "Lightning Roulette",
      viewers: "2.1K"
    },
    {
      id: 2,
      name: "SlotQueen",
      followers: "89K",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b950?w=100&h=100&fit=crop&crop=face",
      status: "Live",
      game: "Mega Fortune",
      viewers: "1.8K"
    },
    {
      id: 3,
      name: "BlackjackPro",
      followers: "203K",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      status: "Offline",
      game: "Last seen: Blackjack",
      viewers: null
    }
  ];

  const dailyTasks = [
    { id: 1, task: "Play 10 casino games", progress: 7, total: 10, reward: "10 Comp Points", completed: false },
    { id: 2, task: "Make a deposit", progress: 1, total: 1, reward: "5% Deposit Bonus", completed: true },
    { id: 3, task: "Place 5 sports bets", progress: 3, total: 5, reward: "Free Bet Token", completed: false },
    { id: 4, task: "Win any jackpot", progress: 0, total: 1, reward: "50 Free Spins", completed: false }
  ];

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:ml-64">
      <div className="p-4 space-y-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">Rewards & Community</h1>
          <p className="text-muted-foreground">Track your progress, earn rewards, and connect with other players</p>
        </div>

        {/* Current VIP Status */}
        <Card className="gradient-primary glow-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 bg-primary-foreground/20 rounded-full flex items-center justify-center">
                  <span className="text-2xl">{vipTiers[currentLevel].icon}</span>
                </div>
                <div>
                  <h2 className="text-xl font-bold text-primary-foreground">
                    VIP {vipTiers[currentLevel].name}
                  </h2>
                  <p className="text-primary-foreground/80">Level {currentLevel}</p>
                </div>
              </div>
              <div className="text-right text-primary-foreground">
                <div className="text-sm opacity-80">Rakeback</div>
                <div className="text-2xl font-bold">{vipTiers[currentLevel].rakeback}%</div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-primary-foreground/80 text-sm">
                <span>Progress to {vipTiers[currentLevel + 1]?.name || "Max Level"}</span>
                <span>${currentWager.toLocaleString()} / ${nextTierWager.toLocaleString()}</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Coins className="w-6 h-6 text-primary" />
              </div>
              <div className="text-2xl font-bold">12,450</div>
              <div className="text-sm text-muted-foreground">Comp Points</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <TrendingUp className="w-6 h-6 text-success" />
              </div>
              <div className="text-2xl font-bold">$456.78</div>
              <div className="text-sm text-muted-foreground">Total Rakeback</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Trophy className="w-6 h-6 text-accent" />
              </div>
              <div className="text-2xl font-bold">28</div>
              <div className="text-sm text-muted-foreground">Achievements</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-warning/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Flame className="w-6 h-6 text-warning" />
              </div>
              <div className="text-2xl font-bold">15</div>
              <div className="text-sm text-muted-foreground">Day Streak</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="vip" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="vip">VIP Levels</TabsTrigger>
            <TabsTrigger value="tasks">Daily Tasks</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="streamers">Streamers</TabsTrigger>
          </TabsList>

          <TabsContent value="vip">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Crown className="w-5 h-5 text-primary" />
                  VIP Program
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {vipTiers.map((tier) => (
                    <Card 
                      key={tier.level} 
                      className={`${currentLevel === tier.level ? 'border-primary glow-primary' : ''} ${
                        currentLevel > tier.level ? 'bg-muted/50' : ''
                      }`}
                    >
                      <CardContent className="p-4 text-center">
                        <div className={`w-16 h-16 ${tier.color} rounded-full flex items-center justify-center mx-auto mb-3`}>
                          <span className="text-2xl">{tier.icon}</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">{tier.name}</h3>
                        <p className="text-sm text-muted-foreground mb-3">Level {tier.level}</p>
                        
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Min Wager:</span>
                            <span className="font-semibold">${tier.minWager.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Rakeback:</span>
                            <span className="font-semibold text-success">{tier.rakeback}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Bonus:</span>
                            <span className="font-semibold text-primary">+{tier.bonuses}%</span>
                          </div>
                        </div>
                        
                        {currentLevel === tier.level && (
                          <Badge className="mt-3 bg-primary text-primary-foreground">
                            Current Level
                          </Badge>
                        )}
                        {currentLevel > tier.level && (
                          <Badge className="mt-3 bg-success text-success-foreground">
                            Completed
                          </Badge>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tasks">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  Daily Tasks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dailyTasks.map((task) => (
                    <Card key={task.id} className={task.completed ? 'bg-success/5 border-success/20' : ''}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold">{task.task}</h4>
                          <Badge 
                            variant={task.completed ? "default" : "outline"}
                            className={task.completed ? "bg-success text-success-foreground" : ""}
                          >
                            {task.reward}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3">
                          <Progress 
                            value={(task.progress / task.total) * 100} 
                            className="flex-1" 
                          />
                          <span className="text-sm text-muted-foreground">
                            {task.progress}/{task.total}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-primary" />
                  Achievements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {achievements.map((achievement) => (
                    <Card 
                      key={achievement.id} 
                      className={achievement.completed ? 'bg-success/5 border-success/20' : 'opacity-60'}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                            achievement.completed ? 'bg-success/20' : 'bg-muted'
                          }`}>
                            <span className="text-lg">{achievement.icon}</span>
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold mb-1">{achievement.name}</h4>
                            <p className="text-sm text-muted-foreground mb-2">{achievement.description}</p>
                            <Badge 
                              variant={achievement.completed ? "default" : "outline"}
                              className={achievement.completed ? "bg-success text-success-foreground" : ""}
                            >
                              {achievement.reward}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="streamers">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-primary" />
                  Featured Streamers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {streamers.map((streamer) => (
                    <Card key={streamer.id} className="hover:border-primary/50 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <div className="relative">
                            <Avatar className="w-16 h-16">
                              <AvatarImage src={streamer.avatar} alt={streamer.name} />
                              <AvatarFallback>{streamer.name[0]}</AvatarFallback>
                            </Avatar>
                            {streamer.status === "Live" && (
                              <div className="absolute -top-1 -right-1 w-4 h-4 bg-destructive rounded-full border-2 border-background" />
                            )}
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-semibold">{streamer.name}</h4>
                              {streamer.status === "Live" && (
                                <Badge className="bg-destructive text-destructive-foreground text-xs">
                                  🔴 Live
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground mb-1">{streamer.followers} followers</p>
                            <p className="text-sm">{streamer.game}</p>
                            {streamer.viewers && (
                              <p className="text-xs text-muted-foreground">{streamer.viewers} watching</p>
                            )}
                          </div>
                          
                          <div className="flex flex-col gap-2">
                            <Button size="sm" variant={streamer.status === "Live" ? "default" : "outline"}>
                              {streamer.status === "Live" ? "Watch" : "Follow"}
                            </Button>
                            {streamer.status === "Live" && (
                              <Button size="sm" variant="outline">
                                Copy Bet
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                <Button className="w-full mt-4" variant="outline">
                  View All Streamers
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}