import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Play, TrendingUp, Star, Clock, Users, Trophy, Zap, Gift } from "lucide-react";

export function Homepage() {
  const topGames = [
    {
      id: 1,
      name: "Mega Fortune",
      category: "Slots",
      image: "https://images.unsplash.com/photo-1603410246916-9b2ca82acdd7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbG90JTIwbWFjaGluZSUyMGNhc2lub3xlbnwxfHx8fDE3NTU2OTEzNzR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      jackpot: "$1.2M",
      hot: true
    },
    {
      id: 2,
      name: "Texas Hold'em",
      category: "Poker",
      image: "https://images.unsplash.com/photo-1633629544357-14223c9837d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb2tlciUyMGNhcmRzJTIwY2FzaW5vfGVufDF8fHx8MTc1NTc3MzQ1MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "2.1k",
      new: true
    },
    {
      id: 3,
      name: "Lightning Roulette",
      category: "Live Casino",
      image: "https://images.unsplash.com/photo-1688873157896-432c9a44eaae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXNpbm8lMjBnYW1pbmclMjBuZW9uJTIwbGlnaHRzfGVufDF8fHx8MTc1NTc4NzQ1Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      multiplier: "500x",
      live: true
    }
  ];

  const sportsOdds = [
    {
      match: "Real Madrid vs Barcelona",
      sport: "Football",
      time: "19:00",
      odds: { home: "2.10", draw: "3.20", away: "3.50" }
    },
    {
      match: "Lakers vs Warriors",
      sport: "Basketball",
      time: "21:30",
      odds: { home: "1.85", away: "1.95" }
    }
  ];

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:ml-64">
      <div className="p-4 space-y-6">
        {/* Hero Section */}
        <Card className="relative overflow-hidden bg-gradient-to-r from-primary/20 to-accent/20 border-primary/30">
          <div className="absolute inset-0 bg-black/20" />
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1688873157896-432c9a44eaae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXNpbm8lMjBnYW1pbmclMjBuZW9uJTIwbGlnaHRzfGVufDF8fHx8MTc1NTc4NzQ1Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Casino Hero"
            className="absolute inset-0 w-full h-full object-cover opacity-30"
          />
          <CardContent className="relative z-10 p-6 md:p-8">
            <div className="max-w-2xl">
              <Badge className="mb-4 bg-accent text-accent-foreground">
                🎉 Welcome Bonus
              </Badge>
              <h2 className="text-2xl md:text-4xl font-bold mb-4">
                Get <span className="text-gradient-primary">200% Bonus</span> + 100 Free Spins
              </h2>
              <p className="text-muted-foreground mb-6 text-lg">
                Join the ultimate crypto casino experience with instant deposits and withdrawals
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button size="lg" className="gradient-primary glow-primary">
                  <Gift className="w-5 h-5 mr-2" />
                  Claim Bonus
                </Button>
                <Button size="lg" variant="outline" className="border-primary text-primary">
                  <Play className="w-5 h-5 mr-2" />
                  Play Demo
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Promotions Banner */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-gradient-accent border-accent/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 bg-accent-foreground/20 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-accent-foreground" />
              </div>
              <div>
                <h3 className="font-semibold text-accent-foreground">Lightning Deals</h3>
                <p className="text-accent-foreground/80 text-sm">50% Rakeback This Hour</p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-success border-success/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 bg-success-foreground/20 rounded-lg flex items-center justify-center">
                <Trophy className="w-6 h-6 text-success-foreground" />
              </div>
              <div>
                <h3 className="font-semibold text-success-foreground">Tournament</h3>
                <p className="text-success-foreground/80 text-sm">$50K Prize Pool</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Top Games */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Top Games
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {topGames.map((game) => (
                <Card key={game.id} className="group cursor-pointer hover:border-primary/50 transition-colors">
                  <CardContent className="p-0">
                    <div className="relative overflow-hidden rounded-t-lg">
                      <ImageWithFallback
                        src={game.image}
                        alt={game.name}
                        className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-2 left-2 flex gap-2">
                        {game.hot && (
                          <Badge className="bg-accent text-accent-foreground text-xs">
                            🔥 Hot
                          </Badge>
                        )}
                        {game.new && (
                          <Badge className="bg-primary text-primary-foreground text-xs">
                            ✨ New
                          </Badge>
                        )}
                        {game.live && (
                          <Badge className="bg-success text-success-foreground text-xs">
                            🔴 Live
                          </Badge>
                        )}
                      </div>
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Button size="sm" className="gradient-primary">
                          <Play className="w-4 h-4 mr-2" />
                          Play Now
                        </Button>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold mb-1">{game.name}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{game.category}</p>
                      <div className="flex items-center justify-between">
                        {game.jackpot && (
                          <span className="text-sm font-semibold text-primary">
                            💰 {game.jackpot}
                          </span>
                        )}
                        {game.players && (
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {game.players}
                          </span>
                        )}
                        {game.multiplier && (
                          <span className="text-sm font-semibold text-accent">
                            ⚡ {game.multiplier}
                          </span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Sports Betting */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-primary" />
              Live Sports
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sportsOdds.map((match, index) => (
                <Card key={index} className="border-muted">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold">{match.match}</h4>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>{match.sport}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {match.time}
                          </span>
                        </div>
                      </div>
                      <Badge variant="outline" className="bg-success/10 text-success border-success/30">
                        Live
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      <Button variant="outline" className="h-auto py-2 px-3 flex flex-col">
                        <span className="text-xs text-muted-foreground">Home</span>
                        <span className="font-semibold">{match.odds.home}</span>
                      </Button>
                      {match.odds.draw && (
                        <Button variant="outline" className="h-auto py-2 px-3 flex flex-col">
                          <span className="text-xs text-muted-foreground">Draw</span>
                          <span className="font-semibold">{match.odds.draw}</span>
                        </Button>
                      )}
                      <Button variant="outline" className="h-auto py-2 px-3 flex flex-col">
                        <span className="text-xs text-muted-foreground">Away</span>
                        <span className="font-semibold">{match.odds.away}</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <Button className="w-full mt-4" variant="outline">
              View All Sports
            </Button>
          </CardContent>
        </Card>

        {/* Trust Indicators */}
        <Card className="bg-muted/50">
          <CardContent className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Star className="w-6 h-6 text-primary" />
                </div>
                <h4 className="font-semibold">Provably Fair</h4>
                <p className="text-sm text-muted-foreground">Verified Games</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Zap className="w-6 h-6 text-success" />
                </div>
                <h4 className="font-semibold">Instant Payouts</h4>
                <p className="text-sm text-muted-foreground">Within 5 minutes</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <h4 className="font-semibold">50K+ Players</h4>
                <p className="text-sm text-muted-foreground">Active Community</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-warning/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Trophy className="w-6 h-6 text-warning" />
                </div>
                <h4 className="font-semibold">Licensed</h4>
                <p className="text-sm text-muted-foreground">Curacao Gaming</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}