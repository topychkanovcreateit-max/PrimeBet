import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Switch } from "./ui/switch";
import { Separator } from "./ui/separator";
import { 
  User, 
  Shield, 
  Bell, 
  Eye, 
  Settings, 
  LogOut,
  Crown,
  TrendingUp,
  Calendar,
  Mail,
  Phone,
  MapPin,
  Lock
} from "lucide-react";

export function Profile() {
  return (
    <div className="min-h-screen pb-20 md:pb-0 md:ml-64">
      <div className="p-4 space-y-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">Profile</h1>
          <p className="text-muted-foreground">Manage your account settings and preferences</p>
        </div>

        {/* Profile Header */}
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              <div className="relative">
                <Avatar className="w-24 h-24">
                  <AvatarImage src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face" alt="Profile" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-2 -right-2">
                  <Badge className="bg-primary text-primary-foreground">
                    <Crown className="w-3 h-3 mr-1" />
                    VIP Gold
                  </Badge>
                </div>
              </div>
              
              <div className="flex-1 text-center md:text-left">
                <h2 className="text-2xl font-bold mb-2">John Doe</h2>
                <p className="text-muted-foreground mb-4">Member since March 2024</p>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-xl font-bold text-primary">$12,345</div>
                    <div className="text-sm text-muted-foreground">Total Wagered</div>
                  </div>
                  <div>
                    <div className="text-xl font-bold text-success">$1,234</div>
                    <div className="text-sm text-muted-foreground">Total Won</div>
                  </div>
                  <div>
                    <div className="text-xl font-bold text-accent">156</div>
                    <div className="text-sm text-muted-foreground">Games Played</div>
                  </div>
                  <div>
                    <div className="text-xl font-bold text-warning">28</div>
                    <div className="text-sm text-muted-foreground">Achievements</div>
                  </div>
                </div>
              </div>
              
              <Button variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Account Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5 text-primary" />
              Account Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Username</label>
                <Input value="johndoe123" readOnly className="bg-muted" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <div className="flex items-center gap-2">
                  <Input value="john.doe@example.com" readOnly className="bg-muted" />
                  <Badge className="bg-success/20 text-success border-success/30">
                    Verified
                  </Badge>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Phone</label>
                <div className="flex items-center gap-2">
                  <Input value="+1 (555) 123-4567" readOnly className="bg-muted" />
                  <Badge variant="outline">
                    Not Verified
                  </Badge>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Country</label>
                <Input value="United States" readOnly className="bg-muted" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Security & Privacy
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-muted-foreground" />
                <div>
                  <h4 className="font-semibold">Two-Factor Authentication</h4>
                  <p className="text-sm text-muted-foreground">Add an extra layer of security</p>
                </div>
              </div>
              <Switch />
            </div>
            
            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div className="flex items-center gap-3">
                <Eye className="w-5 h-5 text-muted-foreground" />
                <div>
                  <h4 className="font-semibold">Privacy Mode</h4>
                  <p className="text-sm text-muted-foreground">Hide your activity from other players</p>
                </div>
              </div>
              <Switch />
            </div>
            
            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-muted-foreground" />
                <div>
                  <h4 className="font-semibold">Email Notifications</h4>
                  <p className="text-sm text-muted-foreground">Receive updates about your account</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            
            <Separator />
            
            <Button variant="outline" className="w-full">
              <Lock className="w-4 h-4 mr-2" />
              Change Password
            </Button>
          </CardContent>
        </Card>

        {/* Account Limits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Responsible Gaming
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground text-sm">
              Set limits to help you stay in control of your gaming activities.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Daily Deposit Limit</label>
                <Input placeholder="$500" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Daily Loss Limit</label>
                <Input placeholder="$200" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Session Time Limit (hours)</label>
                <Input placeholder="4" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Cool-off Period</label>
                <Input placeholder="24 hours" />
              </div>
            </div>
            
            <div className="flex gap-2 pt-4">
              <Button>Save Limits</Button>
              <Button variant="outline">Self-Exclusion</Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span className="text-sm">Logged in from new device</span>
                </div>
                <span className="text-xs text-muted-foreground">2 hours ago</span>
              </div>
              
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full" />
                  <span className="text-sm">Deposited $100 BTC</span>
                </div>
                <span className="text-xs text-muted-foreground">1 day ago</span>
              </div>
              
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-accent rounded-full" />
                  <span className="text-sm">Won $250 on Lightning Roulette</span>
                </div>
                <span className="text-xs text-muted-foreground">2 days ago</span>
              </div>
              
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-warning rounded-full" />
                  <span className="text-sm">Reached VIP Gold level</span>
                </div>
                <span className="text-xs text-muted-foreground">3 days ago</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Account Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Account Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <Mail className="w-4 h-4 mr-2" />
              Contact Support
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Shield className="w-4 h-4 mr-2" />
              Download Account Data
            </Button>
            <Button variant="destructive" className="w-full justify-start">
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}