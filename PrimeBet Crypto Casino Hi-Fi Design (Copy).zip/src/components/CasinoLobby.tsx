import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Search, Filter, Play, Star, Users, Zap, Crown, Gamepad2 } from "lucide-react";

export function CasinoLobby() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const games = [
    {
      id: 1,
      name: "Mega Fortune Dreams",
      category: "slots",
      provider: "NetEnt",
      image: "https://images.unsplash.com/photo-1603410246916-9b2ca82acdd7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbG90JTIwbWFjaGluZSUyMGNhc2lub3xlbnwxfHx8fDE3NTU2OTEzNzR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      jackpot: "$2.4M",
      rtp: "96.4%",
      volatility: "High",
      tags: ["jackpot", "popular", "hot"]
    },
    {
      id: 2,
      name: "Lightning Blackjack",
      category: "table",
      provider: "Evolution",
      image: "https://images.unsplash.com/photo-1742666978255-007e0fcfc0c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibGFja2phY2slMjBjYXNpbm8lMjB0YWJsZXxlbnwxfHx8fDE3NTU3ODc1NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "234",
      minBet: "$1",
      maxBet: "$1000",
      tags: ["live", "multiplier"]
    },
    {
      id: 3,
      name: "Lightning Roulette",
      category: "live",
      provider: "Evolution",
      image: "https://images.unsplash.com/photo-1592602944193-0848995f4b5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb3VsZXR0ZSUyMHdoZWVsJTIwY2FzaW5vfGVufDF8fHx8MTc1NTc3MjIyM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "567",
      multiplier: "500x",
      tags: ["live", "popular", "multiplier"]
    },
    {
      id: 4,
      name: "Crash Galaxy",
      category: "crash",
      provider: "PrimeBet",
      image: "https://images.unsplash.com/photo-1688873157896-432c9a44eaae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXNpbm8lMjBnYW1pbmclMjBuZW9uJTIwbGlnaHRzfGVufDF8fHx8MTc1NTc4NzQ1Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      maxMultiplier: "1000x",
      lastCrash: "3.45x",
      tags: ["exclusive", "hot"]
    },
    {
      id: 5,
      name: "Texas Hold'em Pro",
      category: "table",
      provider: "Ezugi",
      image: "https://images.unsplash.com/photo-1633629544357-14223c9837d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb2tlciUyMGNhcmRzJTIwY2FzaW5vfGVufDF8fHx8MTc1NTc3MzQ1MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "89",
      buyIn: "$10-$500",
      tags: ["tournament"]
    },
    {
      id: 6,
      name: "Dice Master",
      category: "dice",
      provider: "PrimeBet", 
      image: "https://images.unsplash.com/photo-1739133710741-1468de0acf26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWNlJTIwY2FzaW5vJTIwZ2FtaW5nfGVufDF8fHx8MTc1NTcxNjQzMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      winChance: "49.5%",
      multiplier: "2x",
      tags: ["provably-fair", "exclusive"]
    }
  ];

  const categories = [
    { id: "all", name: "All Games", icon: Gamepad2 },
    { id: "slots", name: "Slots", icon: Crown },
    { id: "live", name: "Live Casino", icon: Users },
    { id: "table", name: "Table Games", icon: Star },
    { id: "crash", name: "Crash", icon: Zap },
    { id: "dice", name: "Dice", icon: Gamepad2 }
  ];

  const filteredGames = games.filter(game => {
    const matchesSearch = game.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         game.provider.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || game.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getTagColor = (tag: string) => {
    const colors = {
      hot: "bg-accent text-accent-foreground",
      popular: "bg-primary text-primary-foreground",
      new: "bg-success text-success-foreground",
      live: "bg-destructive text-destructive-foreground",
      exclusive: "bg-gradient-primary text-primary-foreground",
      jackpot: "bg-warning text-warning-foreground",
      multiplier: "bg-accent text-accent-foreground",
      "provably-fair": "bg-success text-success-foreground",
      tournament: "bg-primary text-primary-foreground"
    };
    return colors[tag as keyof typeof colors] || "bg-muted text-muted-foreground";
  };

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:ml-64">
      <div className="p-4">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">Casino Lobby</h1>
          <p className="text-muted-foreground">Choose from thousands of games from top providers</p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search games..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filters
          </Button>
        </div>

        {/* Categories */}
        <div className="flex overflow-x-auto gap-2 mb-6 pb-2">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                className={`flex-shrink-0 flex items-center gap-2 ${
                  selectedCategory === category.id ? "bg-primary text-primary-foreground" : ""
                }`}
                onClick={() => setSelectedCategory(category.id)}
              >
                <Icon className="w-4 h-4" />
                {category.name}
              </Button>
            );
          })}
        </div>

        {/* Featured Promotions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Card className="bg-gradient-accent border-accent/30 overflow-hidden">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-16 h-16 bg-accent-foreground/20 rounded-lg flex items-center justify-center">
                <Crown className="w-8 h-8 text-accent-foreground" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-accent-foreground mb-1">Slot Tournament</h3>
                <p className="text-accent-foreground/80 text-sm mb-2">$100K Prize Pool</p>
                <Button size="sm" variant="secondary">
                  Join Now
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-success border-success/30 overflow-hidden">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-16 h-16 bg-success-foreground/20 rounded-lg flex items-center justify-center">
                <Zap className="w-8 h-8 text-success-foreground" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-success-foreground mb-1">Happy Hour</h3>
                <p className="text-success-foreground/80 text-sm mb-2">Double Comp Points</p>
                <Button size="sm" variant="secondary">
                  Play Now
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredGames.map((game) => (
            <Card key={game.id} className="group cursor-pointer hover:border-primary/50 transition-all hover:scale-105">
              <CardContent className="p-0">
                <div className="relative overflow-hidden rounded-t-lg">
                  <ImageWithFallback
                    src={game.image}
                    alt={game.name}
                    className="w-full h-32 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  
                  {/* Tags */}
                  <div className="absolute top-2 left-2 flex flex-col gap-1">
                    {game.tags.slice(0, 2).map((tag) => (
                      <Badge key={tag} className={`text-xs px-2 py-0.5 ${getTagColor(tag)}`}>
                        {tag === "hot" && "🔥"}
                        {tag === "popular" && "⭐"}
                        {tag === "new" && "✨"}
                        {tag === "live" && "🔴"}
                        {tag === "exclusive" && "👑"}
                        {tag === "jackpot" && "💰"}
                        {tag === "multiplier" && "⚡"}
                        {tag === "provably-fair" && "✅"}
                        {tag === "tournament" && "🏆"}
                        {tag.charAt(0).toUpperCase() + tag.slice(1).replace("-", " ")}
                      </Badge>
                    ))}
                  </div>

                  {/* Special indicators */}
                  <div className="absolute top-2 right-2">
                    {game.jackpot && (
                      <Badge className="bg-warning text-warning-foreground text-xs font-bold">
                        {game.jackpot}
                      </Badge>
                    )}
                    {game.players && (
                      <Badge className="bg-success/20 text-success border-success/30 text-xs">
                        {game.players}👥
                      </Badge>
                    )}
                  </div>

                  {/* Play overlay */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="flex flex-col gap-2">
                      <Button size="sm" className="gradient-primary glow-primary">
                        <Play className="w-4 h-4 mr-2" />
                        Play Now
                      </Button>
                      <Button size="sm" variant="outline">
                        Demo
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="p-3">
                  <h3 className="font-semibold text-sm mb-1 truncate">{game.name}</h3>
                  <p className="text-xs text-muted-foreground mb-2">{game.provider}</p>
                  
                  {/* Game stats */}
                  <div className="space-y-1 text-xs">
                    {game.rtp && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">RTP:</span>
                        <span className="text-success">{game.rtp}</span>
                      </div>
                    )}
                    {game.minBet && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Min Bet:</span>
                        <span>{game.minBet}</span>
                      </div>
                    )}
                    {game.maxMultiplier && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Max Win:</span>
                        <span className="text-accent">{game.maxMultiplier}</span>
                      </div>
                    )}
                    {game.winChance && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Win Chance:</span>
                        <span className="text-primary">{game.winChance}</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredGames.length === 0 && (
          <div className="text-center py-12">
            <Gamepad2 className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No games found</h3>
            <p className="text-muted-foreground mb-4">Try adjusting your search or filters</p>
            <Button onClick={() => {setSearchQuery(""); setSelectedCategory("all");}}>
              Clear Filters
            </Button>
          </div>
        )}

        {/* Load More */}
        {filteredGames.length > 0 && (
          <div className="text-center mt-8">
            <Button variant="outline" size="lg">
              Load More Games
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}