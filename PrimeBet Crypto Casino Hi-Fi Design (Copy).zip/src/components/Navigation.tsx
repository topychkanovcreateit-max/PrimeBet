import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Home, Trophy, Gamepad2, Wallet, User, Gift } from "lucide-react";

interface NavigationProps {
  activeScreen: string;
  onScreenChange: (screen: string) => void;
}

export function Navigation({ activeScreen, onScreenChange }: NavigationProps) {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'sports', label: 'Sports', icon: Trophy },
    { id: 'casino', label: 'Casino', icon: Gamepad2 },
    { id: 'wallet', label: 'Wallet', icon: Wallet },
    { id: 'rewards', label: 'Rewards', icon: Gift },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <>
      {/* Top Header */}
      <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">P</span>
          </div>
          <h1 className="text-xl font-bold text-gradient-primary">PrimeBet</h1>
        </div>
        
        <div className="flex items-center gap-3">
          <Badge className="bg-success/20 text-success border-success/30">
            VIP Gold
          </Badge>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Balance</div>
            <div className="font-semibold">$1,234.56</div>
          </div>
        </div>
      </header>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-2 md:hidden">
        <div className="grid grid-cols-6 gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            
            return (
              <Button
                key={item.id}
                variant={isActive ? "default" : "ghost"}
                size="sm"
                className={`flex flex-col gap-1 h-auto py-2 px-1 ${
                  isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
                onClick={() => onScreenChange(item.id)}
              >
                <Icon className="w-4 h-4" />
                <span className="text-xs">{item.label}</span>
              </Button>
            );
          })}
        </div>
      </nav>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex fixed left-0 top-0 bottom-0 w-64 bg-card border-r border-border flex-col">
        <div className="p-6 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-xl">P</span>
            </div>
            <h1 className="text-2xl font-bold text-gradient-primary">PrimeBet</h1>
          </div>
        </div>
        
        <nav className="flex-1 p-4">
          <div className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeScreen === item.id;
              
              return (
                <Button
                  key={item.id}
                  variant={isActive ? "default" : "ghost"}
                  className={`w-full justify-start gap-3 ${
                    isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                  }`}
                  onClick={() => onScreenChange(item.id)}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                </Button>
              );
            })}
          </div>
        </nav>
        
        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
            <Badge className="bg-success/20 text-success border-success/30">
              VIP Gold
            </Badge>
            <div>
              <div className="font-semibold">$1,234.56</div>
              <div className="text-sm text-muted-foreground">Balance</div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}