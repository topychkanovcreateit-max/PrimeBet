import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Separator } from "./ui/separator";
import { Progress } from "./ui/progress";
import { 
  Wallet as WalletIcon, 
  TrendingUp, 
  TrendingDown, 
  Copy, 
  QrCode, 
  ArrowUpRight, 
  ArrowDownLeft,
  Clock,
  CheckCircle,
  XCircle,
  Bitcoin,
  Zap
} from "lucide-react";

export function Wallet() {
  const [selectedCrypto, setSelectedCrypto] = useState("BTC");
  const [depositAmount, setDepositAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawAddress, setWithdrawAddress] = useState("");

  const cryptos = [
    { 
      symbol: "BTC", 
      name: "Bitcoin", 
      balance: "0.05234", 
      usdValue: "2,341.56", 
      icon: "₿",
      network: "Bitcoin",
      minDeposit: "0.0001",
      minWithdraw: "0.001",
      fee: "0.0005"
    },
    { 
      symbol: "ETH", 
      name: "Ethereum", 
      balance: "1.2456", 
      usdValue: "3,127.89", 
      icon: "Ξ",
      network: "Ethereum",
      minDeposit: "0.001",
      minWithdraw: "0.01",
      fee: "0.005"
    },
    { 
      symbol: "USDT", 
      name: "Tether", 
      balance: "1,234.56", 
      usdValue: "1,234.56", 
      icon: "₮",
      network: "TRC20",
      minDeposit: "10",
      minWithdraw: "20",
      fee: "1"
    },
    { 
      symbol: "LTC", 
      name: "Litecoin", 
      balance: "12.789", 
      usdValue: "1,156.43", 
      icon: "Ł",
      network: "Litecoin",
      minDeposit: "0.01",
      minWithdraw: "0.1",
      fee: "0.01"
    }
  ];

  const transactions = [
    {
      id: "1",
      type: "deposit",
      crypto: "BTC",
      amount: "0.001",
      usdValue: "67.85",
      status: "completed",
      time: "2 hours ago",
      txHash: "bc1q...7x9a"
    },
    {
      id: "2", 
      type: "withdraw",
      crypto: "ETH",
      amount: "0.5",
      usdValue: "1,256.30",
      status: "pending",
      time: "5 hours ago",
      txHash: "0x...f2d1"
    },
    {
      id: "3",
      type: "deposit",
      crypto: "USDT",
      amount: "500",
      usdValue: "500.00",
      status: "completed",
      time: "1 day ago",
      txHash: "TR7N...HqWx"
    }
  ];

  const selectedCryptoData = cryptos.find(c => c.symbol === selectedCrypto);
  const totalUsdValue = cryptos.reduce((sum, crypto) => sum + parseFloat(crypto.usdValue.replace(",", "")), 0);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-success" />;
      case "pending":
        return <Clock className="w-4 h-4 text-warning" />;
      case "failed":
        return <XCircle className="w-4 h-4 text-destructive" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:ml-64">
      <div className="p-4 space-y-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">Wallet</h1>
          <p className="text-muted-foreground">Manage your crypto assets and transactions</p>
        </div>

        {/* Portfolio Overview */}
        <Card className="gradient-primary glow-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-primary-foreground">Total Balance</h2>
                <p className="text-primary-foreground/80">All cryptocurrencies</p>
              </div>
              <WalletIcon className="w-8 h-8 text-primary-foreground" />
            </div>
            <div className="text-3xl font-bold text-primary-foreground mb-2">
              ${totalUsdValue.toLocaleString()}
            </div>
            <div className="flex items-center gap-2 text-primary-foreground/80">
              <TrendingUp className="w-4 h-4" />
              <span>+12.5% (24h)</span>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="cursor-pointer hover:border-primary/50 transition-colors">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <ArrowDownLeft className="w-6 h-6 text-success" />
              </div>
              <h3 className="font-semibold">Deposit</h3>
              <p className="text-sm text-muted-foreground">Add crypto to wallet</p>
            </CardContent>
          </Card>
          
          <Card className="cursor-pointer hover:border-primary/50 transition-colors">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <ArrowUpRight className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-semibold">Withdraw</h3>
              <p className="text-sm text-muted-foreground">Send crypto out</p>
            </CardContent>
          </Card>
        </div>

        {/* Crypto Balances */}
        <Card>
          <CardHeader>
            <CardTitle>Your Assets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {cryptos.map((crypto) => (
                <div key={crypto.symbol} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                      <span className="font-bold text-primary">{crypto.icon}</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">{crypto.name}</h4>
                      <p className="text-sm text-muted-foreground">{crypto.network}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{crypto.balance} {crypto.symbol}</div>
                    <div className="text-sm text-muted-foreground">${crypto.usdValue}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>  
        </Card>

        {/* Deposit/Withdraw */}
        <Card>
          <CardHeader>
            <CardTitle>Deposit & Withdraw</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="deposit">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="deposit">Deposit</TabsTrigger>
                <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
              </TabsList>

              <TabsContent value="deposit" className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Select Cryptocurrency</label>
                  <div className="grid grid-cols-4 gap-2">
                    {cryptos.map((crypto) => (
                      <Button
                        key={crypto.symbol}
                        variant={selectedCrypto === crypto.symbol ? "default" : "outline"}
                        className="flex flex-col h-auto py-3"
                        onClick={() => setSelectedCrypto(crypto.symbol)}
                      >
                        <span className="font-bold text-lg">{crypto.icon}</span>
                        <span className="text-xs">{crypto.symbol}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                {selectedCryptoData && (
                  <div className="space-y-4">
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Deposit Address</h4>
                      <div className="flex items-center gap-2 p-3 bg-background rounded border font-mono text-sm">
                        <span className="flex-1 truncate">bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh</span>
                        <Button size="sm" variant="ghost">
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex items-center gap-2 mt-2">
                        <Button size="sm" variant="outline">
                          <QrCode className="w-4 h-4 mr-2" />
                          Show QR
                        </Button>
                        <Badge variant="outline" className="text-xs">
                          Network: {selectedCryptoData.network}
                        </Badge>
                      </div>
                    </div>

                    <div className="bg-muted/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Deposit Information</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Minimum Deposit:</span>
                          <span>{selectedCryptoData.minDeposit} {selectedCrypto}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Confirmations:</span>
                          <span>3 blocks</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Processing Time:</span>
                          <span>~10 minutes</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="withdraw" className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Select Cryptocurrency</label>
                  <div className="grid grid-cols-4 gap-2">
                    {cryptos.map((crypto) => (
                      <Button
                        key={crypto.symbol}
                        variant={selectedCrypto === crypto.symbol ? "default" : "outline"}
                        className="flex flex-col h-auto py-3"
                        onClick={() => setSelectedCrypto(crypto.symbol)}
                      >
                        <span className="font-bold text-lg">{crypto.icon}</span>
                        <span className="text-xs">{crypto.symbol}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                {selectedCryptoData && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Withdrawal Address</label>
                      <Input 
                        placeholder={`Enter ${selectedCrypto} address`}
                        value={withdrawAddress}
                        onChange={(e) => setWithdrawAddress(e.target.value)}
                        className="font-mono text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Amount</label>
                      <div className="relative">
                        <Input 
                          type="number"
                          placeholder="0.00"
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                          className="pr-16"
                        />
                        <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                          {selectedCrypto}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-2 text-sm">
                        <span className="text-muted-foreground">
                          Available: {selectedCryptoData.balance} {selectedCrypto}
                        </span>
                        <Button variant="ghost" size="sm" onClick={() => setWithdrawAmount(selectedCryptoData.balance)}>
                          Max
                        </Button>
                      </div>
                    </div>

                    <div className="bg-muted/50 p-4 rounded-lg">
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Network Fee:</span>
                          <span>{selectedCryptoData.fee} {selectedCrypto}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">You'll Receive:</span>
                          <span className="font-semibold">
                            {withdrawAmount ? (parseFloat(withdrawAmount) - parseFloat(selectedCryptoData.fee)).toFixed(6) : "0.00"} {selectedCrypto}
                          </span>
                        </div>
                        <Separator />
                        <div className="flex justify-between font-semibold">
                          <span>Total:</span>
                          <span>{withdrawAmount || "0.00"} {selectedCrypto}</span>
                        </div>
                      </div>
                    </div>

                    <Button className="w-full gradient-primary" size="lg">
                      <ArrowUpRight className="w-5 h-5 mr-2" />
                      Withdraw {selectedCrypto}
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Transaction History */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {transactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      tx.type === "deposit" ? "bg-success/20" : "bg-accent/20"
                    }`}>
                      {tx.type === "deposit" ? 
                        <ArrowDownLeft className="w-5 h-5 text-success" /> :
                        <ArrowUpRight className="w-5 h-5 text-accent" />
                      }
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold capitalize">{tx.type}</span>
                        {getStatusIcon(tx.status)}
                      </div>
                      <p className="text-sm text-muted-foreground">{tx.time}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">
                      {tx.type === "deposit" ? "+" : "-"}{tx.amount} {tx.crypto}
                    </div>
                    <div className="text-sm text-muted-foreground">${tx.usdValue}</div>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4">
              View All Transactions
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}