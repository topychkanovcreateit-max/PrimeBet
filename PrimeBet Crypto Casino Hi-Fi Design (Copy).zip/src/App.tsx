import { useState } from "react";
import { Navigation } from "./components/Navigation";
import { Homepage } from "./components/Homepage";
import { Sportsbook } from "./components/Sportsbook";
import { CasinoLobby } from "./components/CasinoLobby";
import { Wallet } from "./components/Wallet";
import { Rewards } from "./components/Rewards";
import { Profile } from "./components/Profile";

export default function App() {
  const [activeScreen, setActiveScreen] = useState("home");

  const renderScreen = () => {
    switch (activeScreen) {
      case "home":
        return <Homepage />;
      case "sports":
        return <Sportsbook />;
      case "casino":
        return <CasinoLobby />;
      case "wallet":
        return <Wallet />;
      case "rewards":
        return <Rewards />;
      case "profile":
        return <Profile />;
      default:
        return <Homepage />;
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation activeScreen={activeScreen} onScreenChange={setActiveScreen} />
      {renderScreen()}
    </div>
  );
}